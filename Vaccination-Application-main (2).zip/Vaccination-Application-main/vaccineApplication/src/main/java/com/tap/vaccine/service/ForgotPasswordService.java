package com.tap.vaccine.service;


public interface ForgotPasswordService {
	
	
	boolean validateForgotPassword(String email, String password, String confirmPassword);
	boolean validateEmail(String email);
	boolean validatePassword(String password);
	boolean validateConfirmPassword(String password);
	boolean resetForgotPassword(String email, String password) throws Exception;
	
	

}
