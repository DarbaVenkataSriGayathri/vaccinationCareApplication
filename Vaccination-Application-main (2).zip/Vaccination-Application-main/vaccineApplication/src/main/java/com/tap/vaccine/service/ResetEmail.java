package com.tap.vaccine.service;

public interface ResetEmail {
	
	boolean sendResetEmail(String to, String newPassword) throws Exception;

	boolean getRegisterEntityByEmail(String email, String password);

}
