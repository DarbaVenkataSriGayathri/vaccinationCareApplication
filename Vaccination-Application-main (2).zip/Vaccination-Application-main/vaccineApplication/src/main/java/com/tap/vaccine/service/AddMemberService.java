package com.tap.vaccine.service;

public interface AddMemberService {
	
	boolean validateAddMember(String memberName, String gender, String dob, String idProof, String idProofNo, String vaccinationType, String dose);


	boolean verifyAddMember(String memberName, String gender, String dob, String idProof, String idProofNo,
			String vaccinationType, String dose);


	boolean validateMemberName(String memberName);


	boolean validateGender(String gender);


	boolean validateDob(String dob);


	boolean validateIdProof(String idProof);


	boolean validateIdProofNo(String idProofNo);


	boolean validateVacccinationType(String vaccinationType);


	boolean validateDose(String dose);

}
