package com.tap.vaccine.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.tap.vaccine.entity.RegisterEntity;

@Component
public class RegisterDAOImpl implements RegisterDAO{
	
	private SessionFactory sessionFactory;
	private Session session;
	
	
	@Autowired
	public RegisterDAOImpl(SessionFactory sessionFactory) {
		
		this.sessionFactory = sessionFactory;
	}
	
	public RegisterDAOImpl() {
		System.out.println("RegisterDAOImpl is Invoked ..");
	}
	
	@Override
	public boolean saveRegisterData(RegisterEntity registerEntity) {
		boolean isDataSaved=false;
		session=null;
		Transaction transaction=null;
		try {
			System.out.println("Before saving data...");
			session = sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.save(registerEntity);
			session.getTransaction().commit();	
			isDataSaved=true;
			System.out.println("Data is Saved Successfully..");
		}
		catch(Exception e) {
			
			if(transaction!=null) {
				transaction.rollback();
				System.out.println("Transaction Rollback"+e.getMessage());
			}
		}
		finally {
			
			if(session!=null) {
				
				
				session.close();
			}
		}
		return isDataSaved;		
	}	
}
