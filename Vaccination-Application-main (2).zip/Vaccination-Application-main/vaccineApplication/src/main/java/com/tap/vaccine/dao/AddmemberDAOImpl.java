package com.tap.vaccine.dao;

import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tap.vaccine.entity.AddMemberEntity;

@Component
public class AddmemberDAOImpl implements AddMemberDAO{
		private SessionFactory sessionFactory;
	
	public AddmemberDAOImpl() {
		System.out.println("addMemberDAO class..");
	}
	
	@Autowired
	public AddmemberDAOImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}

	@Override
	public boolean saveAddMemberDetails(AddMemberEntity addMember) {
		
		Transaction transaction=null;
		Session session=null;
		boolean isDataSaved=false;
		
		try {
			session = sessionFactory.openSession();
			
			transaction = session.beginTransaction();
			
			Serializable save = session.save(addMember);
			session.getTransaction().commit();
			isDataSaved=true;
			System.out.println("Transaction Successfully..");
			
		}
		catch(Exception e){
			if(transaction!=null) {
				
				transaction.rollback();
				System.out.println("transaction rollback");
				
			}	
		}
		finally {
			if(session!=null) {
				session.close();
			}	
		}		
		return isDataSaved;
	}
	
}
