package com.tap.vaccine.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="addmember")
public class AddMemberEntity {
	
	
	public AddMemberEntity() {
		System.out.println("addMember Entity..");
	}
	@Id
	@Column(name="MEMBERID")
	String memberId;
		
	@Column(name="MEMBER_NAME")
	String memberName;
	
	
	@Column(name="GENDER")
	String gender;
	
	@Column(name="DATE_OF_BIRTH")
	String dob;
	
	@Column(name="ID_PROOF")
	String idProof;
	
	@Column(name="ID_PROOF_NO")
	String idProofNumber;
	
	@Column(name="VACCINATION_TYPE")
	String vaccinationType;
	
	@Column(name="DOSE")
	int dose;

	

	public AddMemberEntity(String memberId, String memberName, String gender, String dob, String idProof,
			String idProofNumber, String vaccinationType, int dose) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
		this.gender = gender;
		this.dob = dob;
		this.idProof = idProof;
		this.idProofNumber = idProofNumber;
		this.vaccinationType = vaccinationType;
		this.dose = dose;
	}

	public AddMemberEntity(String memberName, String gender, String dob, String idProof, String idProofNumber,
			String vaccinationType, int dose) {
		super();
		this.memberName = memberName;
		this.gender = gender;
		this.dob = dob;
		this.idProof = idProof;
		this.idProofNumber = idProofNumber;
		this.vaccinationType = vaccinationType;
		this.dose = dose;
	}
	
	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getIdProof() {
		return idProof;
	}

	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}

	public String getIdProofNumber() {
		return idProofNumber;
	}

	public void setIdProofNumber(String idProofNumber) {
		this.idProofNumber = idProofNumber;
	}

	public String getVaccinationType() {
		return vaccinationType;
	}

	public void setVaccinationType(String vaccinationType) {
		this.vaccinationType = vaccinationType;
	}

	public int getDose() {
		return dose;
	}

	public void setDose(int dose) {
		this.dose = dose;
	}
	
	
}
