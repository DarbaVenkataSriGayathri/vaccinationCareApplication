package com.tap.vaccine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.tap.vaccine.service.ForgotPasswordService;

@Controller
public class ForgotPasswordController {

	private ForgotPasswordService forgotPasswordService;

	@Autowired
	public ForgotPasswordController(ForgotPasswordService forgotPasswordService) {

		this.forgotPasswordService = forgotPasswordService;
	}

	public ForgotPasswordController() {
		System.out.println("ForgotPasswordController is an Default Constructor");
	}

	@RequestMapping(value = "/forgotpassword")
	public String forgotPasswordPage() {

		return "/WEB-INF/forgotpassword.jsp";
	}


	@RequestMapping(value = "/resetForgotPassword", method = RequestMethod.POST)
	public String resetForgotPassword(@RequestParam String email, @RequestParam String password,
			@RequestParam String confirmPassword, Model model) throws Exception{
		try {
			if(!forgotPasswordService.validateEmail(email)) {
				model.addAttribute(email, "Enter valid email");
			}
			if(!forgotPasswordService.validatePassword(password)) {
				model.addAttribute("password1", "-> minimum length 8 Characters");
				model.addAttribute("password2", "-> Should have atleast one uppercase letter");
				model.addAttribute("password3", "-> Should have atleast one lowercase letter");
				model.addAttribute("password4", "-> Should have atleast one digit");
				model.addAttribute("password5", "-> Should have atleast one Special character");
			}
					
			if(!forgotPasswordService.validateConfirmPassword(confirmPassword)) {
				model.addAttribute("confirmPassword", "Password doesn't match");
			}
			if(forgotPasswordService.validateForgotPassword(email, password, confirmPassword)) {
				if(forgotPasswordService.resetForgotPassword(email, password)) {
					model.addAttribute("yes", "Password Changed Successfully..");
				}
				else {
					model.addAttribute("no", "Something went wrong");
				}
						
			}				
			else {
				model.addAttribute("no","Invalid email or password");
			}
					
			return "/WEB-INF/forgotpassword.jsp";
		}
		catch (Exception e) {
	        return "/error.jsp"; 
	    }
	}

}