package com.tap.vaccine.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.tap.vaccine.dao.RegisterDAOImpl;
import com.tap.vaccine.entity.RegisterEntity;

@Service
@Component
public class RegisterValidationServiceImpl implements RegisterService {
    private final RegisterDAOImpl registerDAO;
    private final JavaMailSenderImpl javaMailSender;

    @Autowired
    public RegisterValidationServiceImpl(RegisterDAOImpl registerDAO, JavaMailSenderImpl javaMailSender) {
        this.registerDAO = registerDAO;
        this.javaMailSender = javaMailSender;
        System.out.println("RegisterValidationService...invoked");
    }
	
	@Override
	public boolean validateRegisterData(String userName, String password, String confirmPassword, String email, String mobileNumber, String gender, String dateOfBirth) {
		
		
		boolean isValid=true;
		String userNameRegex="[a-zA-Z0-9]+$";
		String passwordRegex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$%*&?!])[a-zA-Z\\d@!?%*&]{8,}$";
		String mobileRegex= "^[6,7,8,9]\\d{9}$";
		
		
		if(userName.isEmpty() || userName == null || userName=="" || !userName.matches(userNameRegex)) {
			
			isValid=false;
			System.out.println("USERNAME IS INVALID "+userName);
		}
		else {
			System.out.println("USERNAME IS VALID "+userName);
		}
		
		if (password == null || password.isEmpty() || !password.matches(passwordRegex)) {
		    isValid = false;
		    System.out.println("PASSWORD IS INVALID " + password);
		} else {
		    System.out.println("PASSWORD IS VALID " + password);
		}
		
		if(confirmPassword==null || confirmPassword.isEmpty() || !confirmPassword.matches(password) ||confirmPassword=="") {
			isValid=false;
			System.out.println("CONFIRMPASSWORD IS INVALID "+confirmPassword);
		}
		else {
			System.out.println("CONFIRMPASSWORD IS VALID "+confirmPassword);
		}
		
		if(email==null || email.isEmpty() || email=="" || !email.contains("@gmail.com")) {
			
			isValid=false;
			System.out.println("EMAIL IS INVALID "+email);
			
		}
		else {
			System.out.println("EMAIL IS VALID "+email);
		}
		
		if(mobileNumber==null || !String.valueOf(mobileNumber).matches(mobileRegex)) {
			isValid=false;
			System.out.println("MOBILE NUMBER IS INVALID "+mobileNumber);
		}
		else {
			System.out.println("MOBILE NUMBER IS VALID "+mobileNumber);
		}
		
		if(gender.isEmpty() || gender==null || gender=="") {
			
			isValid=false;
			System.out.println("GENDER IS INVALID "+gender);
		}
		else {
			System.out.println("GENDER IS VALID "+gender);
		}
		
		if(dateOfBirth==null) {
			
			isValid=false;
			System.out.println("DATE OF BIRTH IS INVALID "+dateOfBirth);
		}
		else {
			System.out.println("DATE OF BIRTH IS VALID "+dateOfBirth);
		}
		return isValid;
		
	}
	
	public boolean validateUserName(String userName) {
		boolean isValid=true;
		String userNameRegex="[a-zA-Z0-9]+$";
		
		if(userName=="" || userName==null || userName.isEmpty() || !userName.matches(userNameRegex)) {
			isValid=false;
			System.out.println("UserName is Invalid");
		}
		else {
			System.out.println("UserName is Valid");
		}
		return isValid;
		
	}
	
	String pwd="";
	public boolean validatePassword(String password) {
	    boolean isValid = true;
	    String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$%*&?!])[a-zA-Z\\d@!?%*&]{8,}$";
	    if (password == null || password.isEmpty() || password.equals("") || !password.matches(passwordRegex)) {
	        isValid = false;
	        System.out.println("Password is Invalid");
	    } else {
	        pwd = password;
	    }
	    return isValid;
	}

	public boolean validateConfirmPassword(String confirmPassword) {
	    boolean isValid = true;
	    if (confirmPassword == null || confirmPassword.equals("") || !confirmPassword.equals(pwd)) {
	        isValid = false;
	        System.out.println("ConfirmPassword is Invalid");
	    } else {
	        System.out.println("ConfirmPassword is Valid");
	    }
	    return isValid;
	}

	public boolean validateEmail(String email) {
	    boolean isValid = true;
	    if (email == null || email.isEmpty() || !email.contains("@gmail.com") || email.equals("")) {
	        isValid = false;
	        System.out.println("Email is Invalid");
	    } else {
	        System.out.println("Email is valid");
	    }
	    return isValid;
	}

	public boolean validateMobileNumber(String mobileNumber) {
		
		boolean isValid=true;
		String mobileRegex= "^[6,7,8,9]\\d{9}$";
		if(mobileNumber==null || mobileNumber.isEmpty() || !mobileNumber.matches(mobileRegex) || mobileNumber=="") {
			isValid=false;
			System.out.println("MobileNumber is Invalid");
		}
		else {
			System.out.println("MobileNumber is valid");
		}
		return isValid;
	}
	
	public boolean validateGender(String gender) {
		
		boolean isValid=true;
		if(gender==null || gender.isEmpty() || gender=="") {
			isValid=false;
			System.out.println("Gender is Invalid");
		}
		else {
			System.out.println("Gender is valid");
		}
		return isValid;
		
	}
	@Override
	public boolean validateDateOfBirth(String dateOfBirth) {
	    boolean isValid = true;
	    if (dateOfBirth == null) {
	        isValid = false;
	        System.out.println("Date Of Birth is Invalid");
	    } else {
	        System.out.println("Date Of Birth is Valid");
	    }
	    return isValid;
	}
	 
	@Override
	@Transactional
	public boolean saveRegisterData(String userName, String password, String email, String mobileNumber, String gender, String dateOfBirth) {
		 boolean flag=false;

		 RegisterEntity registerEntity = new RegisterEntity(userName, password, email, mobileNumber, gender, dateOfBirth);
			System.out.println("saveRegisterData Service invoked..");
			boolean saveSuccess = registerDAO.saveRegisterData(registerEntity);
			if(saveSuccess) {
				SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
				simpleMailMessage.setTo(email);
				simpleMailMessage.setSubject("Register is successfull");
				simpleMailMessage.setText("Hello I am Gayathri I tried to send this mail though my Project Spring i hope that you received this mail :) ");
				try {
					javaMailSender.send(simpleMailMessage);
					flag=true;
					System.out.println("Mail Sent..");
				}
				catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("Error sending mail: " + e.getMessage());
                }
			}
			return flag;	
	}
}
