package com.tap.vaccine.dao;

public interface ForgotPasswordDAO {
	
	
//	boolean updateForgotPassword(RegisterEntity registerEntity);
	boolean getRegisterEntityByEmail(String email, String password);

//	boolean getRegisterEntityByEmail(RegisterEntity entity);
	
}
