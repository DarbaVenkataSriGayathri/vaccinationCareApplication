package com.tap.vaccine.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysql.cj.Session;
import com.tap.vaccine.service.EmailService;
import com.tap.vaccine.service.LoginService;

@Controller
public class LoginController {
	
	private LoginService loginService;
	private EmailService emailService;
	
	
	@Autowired
	public LoginController(LoginService loginService, EmailService emailService) {
		super();
		this.loginService = loginService;
		this.emailService = emailService;
	}
	public LoginController() {
		System.out.println("Login Controller constructor");
	}
	@RequestMapping(value="/loginPage")
	public String navigateToLoginPage() {
		
		return "/WEB-INF/login.jsp";
				
	}
	
	@RequestMapping(value="/loginCredentials", method=RequestMethod.GET)
	public String onLogin(@RequestParam(name = "email") String email, @RequestParam(name = "password") String password, Model model, HttpServletRequest request) throws Exception{
	    System.out.println("Entering onLogin method");
	    
	    try {
	    	
	        boolean isValidCredentials = loginService.validateLoginCredentials(email, password);
	        
	        
	        if (isValidCredentials) {
	            boolean loginMessage = loginService.verifyLoginCredentials(email, password);

	            if (loginMessage) {
	                model.addAttribute("response", "You Successfully login");
	                HttpSession session = request.getSession(true);
	                session.setAttribute("loggedInUserEmail", email);
	                
	                return "redirect:/homepage"; 
	            } else {
	                model.addAttribute("response", "Invalid Email & Password ");
	                return "/WEB-INF/login.jsp";
	            }
	        } else {
	        	
	            model.addAttribute("response", "Please Enter valid Credentials ");
	            return "/WEB-INF/login.jsp";
	        }
	    } catch (Exception e) {
	        model.addAttribute("response", e.getMessage());

	        if (e.getMessage().contains("Account locked")) {
	            try {
					emailService.blockedEmail(email);
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
	        }

	        return "/WEB-INF/login.jsp";
	    }
	}

	@RequestMapping(value = "/homepage", method = RequestMethod.GET)
	public String showHomePage(Model model) {
	    System.out.println("Entering verifyLoginCredentials method");

	    return "/WEB-INF/homepage.jsp";
	}
	
	
}
