package com.tap.vaccine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tap.vaccine.dao.AddMemberDAO;
import com.tap.vaccine.entity.AddMemberEntity;

@Service
public class AddMemberServiceImpl implements AddMemberService{
	
	private AddMemberDAO addMemberDAO;
	
	@Autowired
	public AddMemberServiceImpl(AddMemberDAO addMemberDAO) {
		super();
		this.addMemberDAO = addMemberDAO;
	}

	@Override
	public boolean validateAddMember(String memberName, String gender, String dob, String idProof, String idProofNo,
			String vaccinationType, String dose) {
		System.out.println("validateAddMember service class");
		
		boolean isValid=true;
		if(memberName==null || memberName.isEmpty() || memberName.isBlank()) {
			
			isValid=false;
		}
		
		if(gender==null || gender.isEmpty() || gender.isBlank()) {
			
			isValid=false;
		}
		
		if(dob==null || dob.isBlank() || dob.isEmpty()) {
			
			isValid=false;
			
		}
		
		if(idProof==null || idProof.isBlank() || idProof.isEmpty()) {
			
			isValid=false;
		}
		
		if(idProofNo==null || idProofNo.isBlank() || idProofNo.isEmpty()) {
			isValid=false;
		}
		
		if(vaccinationType==null || vaccinationType.isBlank() || vaccinationType.isEmpty()) {
			
			isValid=false;
		}
		
		if(dose==null || dose.isBlank() || dose.isEmpty()) {
			isValid=false;
		}
			
				
		return isValid;
	}
	
	@Override
	public boolean validateMemberName(String memberName) {
		boolean isValid=true;
		
		if(memberName==null || memberName.isEmpty() || memberName.isBlank()) {
			isValid=false;
		}
		return isValid;
		
		
	}
	
	@Override
	public boolean validateGender(String gender) {
		
		boolean isValid=true;
		
		if(gender==null || gender.isEmpty() || gender.isBlank()) {
			isValid=false;
		}
		return isValid;
	}
	
	@Override
	public boolean validateDob(String dob) {
		
		boolean isValid=true;
		
		if(dob==null || dob.isBlank() || dob.isEmpty()) {
			isValid=false;
		}
		return isValid;
		
	}
	
	@Override
	public boolean validateIdProof(String idProof) {
		boolean isValid=true;
		
		if(idProof==null || idProof.isBlank() || idProof.isEmpty()) {
			isValid=false;
		}
		return isValid;
	}
	
	@Override
	public boolean validateIdProofNo(String idProofNo) {
		boolean isValid=true;
		
		if(idProofNo==null || idProofNo.isBlank() || idProofNo.isEmpty()) {
			isValid=false;
		}
		return isValid;
	}
	
	@Override
	public boolean validateVacccinationType(String vaccinationType) {
		boolean isValid=true;
		
		if(vaccinationType==null || vaccinationType.isBlank() || vaccinationType.isEmpty()) {
			isValid=false;
		}
		return isValid;
		
	}
	
	@Override
	public boolean validateDose(String dose) {
		
		boolean isValid=true;
		if(dose==null || dose.isBlank() || dose.isEmpty()) {
			isValid =false;
		}
		return isValid;
	}
	
	@Override
	public boolean verifyAddMember(String memberName, String gender, String dob, String idProof, String idProofNo,
	        String vaccinationType, String dose) {

	    boolean isValid = validateAddMember(memberName, gender, dob, idProof, idProofNo, vaccinationType, dose);

	    if (isValid) {
	        AddMemberEntity addMember = new AddMemberEntity();
	        addMemberDAO.saveAddMemberDetails(addMember);
	        return true;
	    } else {
	        return false;
	    }
	}
}
