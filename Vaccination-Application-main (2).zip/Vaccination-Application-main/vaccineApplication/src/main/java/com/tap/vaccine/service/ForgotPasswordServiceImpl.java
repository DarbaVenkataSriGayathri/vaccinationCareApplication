package com.tap.vaccine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.tap.vaccine.dao.ForgotPasswordDAO;
import com.tap.vaccine.entity.RegisterEntity;

@Service
@Component
public class ForgotPasswordServiceImpl implements ForgotPasswordService{
	
	private ForgotPasswordDAO forgotPasswordDao;
	private ResetEmailImpl resetEmailService;
	
	@Autowired
	public ForgotPasswordServiceImpl(ForgotPasswordDAO forgotPasswordDao) {
		this.forgotPasswordDao=forgotPasswordDao;
	}

    public  ForgotPasswordServiceImpl(ResetEmailImpl resetEmailService) {
        this.resetEmailService = resetEmailService;
    }
	
	public ForgotPasswordServiceImpl() {
		System.out.println("ForgotPasswordServiceImpl...is executed");
	}

	@Override
	public boolean validateForgotPassword(String email, String password, String confirmPassword) {
		String passwordRegex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d)(?=.*[@$%*&?!])[a-zA-Z\\\\d@!?%*&]{8,}$";
		boolean isValid=true;
		String code="";
		if (email == null || email.isEmpty() || !email.endsWith("@gmail.com")) {
			isValid = false;
		    System.out.println("Email is invalid");
		}
		if (password == null || password.isEmpty() || !password.matches(passwordRegex)){
			isValid = false;
			System.out.println("Password is invalid");
		}
		else {
			code=password;
		}
		
		if(confirmPassword==null || confirmPassword.isEmpty() || !code.equals(confirmPassword)) {
			isValid=false;
			
			System.out.println("Invalid confirmPassword");
		}
		return isValid;
	}
	String code="";
	
	public boolean validateEmail(String email) {
		boolean isValid=true;

		 if (email == null || email.isEmpty() || !email.endsWith("@gmail.com")) 
		 {
		        isValid = false;
		        System.out.println("Email is invalid");
		 }
		return isValid;
		
	}
	@Override
	public boolean validatePassword(String password) {
		
		boolean isValid=true;
		String passwordRegex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d)(?=.*[@$%*&?!])[a-zA-Z\\\\d@!?%*&]{8,}$";
		
		if (password == null || password.isEmpty() || !password.matches(passwordRegex)){
			isValid = false;
			System.out.println("Password is invalid");
		 }
		 else {
			 code=password;
		 }
		 return isValid;
	
	}
	
	public boolean validateConfirmPassword(String confirmPassword) {
		
		boolean isValid=true;
		if (confirmPassword == null || confirmPassword.isEmpty() ||  !code.equals(confirmPassword)) {
			isValid = false;
			System.out.println("Password is invalid");
		}
		return isValid;
		
	}
	

	@Override
	public boolean resetForgotPassword(String email, String password) throws Exception{
		
		return forgotPasswordDao.getRegisterEntityByEmail(email, password);
		
		
	}

		
}
