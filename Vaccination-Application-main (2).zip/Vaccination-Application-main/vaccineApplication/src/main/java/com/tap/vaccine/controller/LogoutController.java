package com.tap.vaccine.controller;

import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LogoutController {
	
	public LogoutController() {
		System.out.println("LogoutController ..");
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletResponse response) {
	    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
	    response.setHeader("Pragma", "no-cache");
	    response.setDateHeader("Expires", 0);
	    
	    return "redirect:/loginPage";
	}
}
