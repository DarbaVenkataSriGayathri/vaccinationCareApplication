package com.tap.vaccine.service;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public class EmailService {
	

	private JavaMailSender javaMailSender;
	
	public EmailService(JavaMailSender javaMailSender) {
		
		this.javaMailSender = javaMailSender;
	}
	
	public boolean blockedEmail(String to) throws Exception {
		
		SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
		
		simpleMailMessage.setTo(to);
		simpleMailMessage.setSubject("Account Blocked");
		simpleMailMessage.setText("You tried to login with invalid Email&Password so You are blocked");
		try {
			
			javaMailSender.send(simpleMailMessage);
			System.out.println("Mail Sent Successfully");
		}
		catch(MailException e) {
			
			System.out.println(e.getMessage());
			throw new Exception("Mail Failed  to Send");
			
		}
		
		return false;	
	}


}
