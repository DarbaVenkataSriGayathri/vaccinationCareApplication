package com.tap.vaccine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tap.vaccine.service.AddMemberService;

@Controller
public class AddMemberController {
	
	private AddMemberService addMemberService;
	
	@Autowired
	public AddMemberController(AddMemberService addMemberService) {
		super();
		this.addMemberService = addMemberService;
	}

	public AddMemberController() {
		System.out.println("addMember Controller");
	}
		
	@RequestMapping(value="/addMember")
	public String addMemberPage() {
		
		return "/WEB-INF/addMember.jsp";
	}
	
	@RequestMapping(value="/addMemberPage")
	public String addMemberPage(@RequestParam(name = "memberName", required = false) String memberName,
            @RequestParam(name = "gender", required = false) String gender,
            @RequestParam(name = "dob", required = false) String dob,
            @RequestParam(name = "idProof", required = false) String idProof,
            @RequestParam(name = "idProofNo", required = false) String idProofNo,
            @RequestParam(name = "vaccinationType", required = false) String vaccinationType,
            @RequestParam(name = "dose", required = false) String dose,
            Model model) {
		System.out.println("addMemberPage Method in Controller");
		
		if(!addMemberService.validateMemberName(memberName)) {
			model.addAttribute("memberName","MEMBERNAME CONTAINS  ALPHABETS & NUMBERS ONLY");
		}
		
		if(!addMemberService.validateGender(gender)) {
			model.addAttribute("gender","GENDER MUST BE CHARECTERS");
		}
		
		if(!addMemberService.validateDob(dob)) {
			model.addAttribute("dob","DATE OF BIRTH MUST BE NUMBERS");
		}
		
		if(!addMemberService.validateIdProof(idProof)) {
			model.addAttribute("idProof","idProof must be contains Charecters");
		}
		
		if(!addMemberService.validateIdProofNo(idProofNo)) {
			model.addAttribute("idProofNo","idProofNo must be number or alphabets or both");
		}
		
		if(!addMemberService.validateVacccinationType(vaccinationType)) {
			model.addAttribute("vaccinationType","vaccinationType must be charecters");
		}
		
		if(!addMemberService.validateDose(dose)) {
			model.addAttribute("dose","dose must contain numbers");
			
		}
		
		if(addMemberService.validateAddMember(memberName, gender, dob, idProof, idProofNo, vaccinationType, dose)) {
			
			if(addMemberService.verifyAddMember(memberName, gender, dob, idProof, idProofNo, vaccinationType, dose)) {
				model.addAttribute("response", "Data Is Successfully Saved");
				
				return "redirect:/homepage.jsp?message=Data%20Is%20Successfully%20Saved";
			}
			else {
				model.addAttribute("no","Data doesn't exit");
			}
		}
		else {
			model.addAttribute("no","Failed...Try Again :(");
		}
		
		
		
		return "/WEB-INF/addMember.jsp";
				
	}

}
