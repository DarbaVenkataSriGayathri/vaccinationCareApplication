package com.tap.vaccine.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import com.tap.vaccine.entity.RegisterEntity;

@Component
public class ForgotPasswordDAOImpl implements ForgotPasswordDAO{
	
	private SessionFactory sessionFactory;
	private Session session;
	private Query query;
	private Throwable hibernateException;
	@Autowired
	public ForgotPasswordDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Autowired
	private JavaMailSender javaMailSender;
	public ForgotPasswordDAOImpl(JavaMailSender javaMailSender) {
		this.javaMailSender=javaMailSender;
	}
	
	public ForgotPasswordDAOImpl() {
		System.out.println("ForgotPasswordDAOImpl constructor");
	}
	@Override
	public boolean getRegisterEntityByEmail(String email, String password) {
		
		boolean isDataChanged=false;
		RegisterEntity entity=null;
		session=null;
		Transaction transaction =null;
		String hql="from RegisterEntity where email= '"+email+"'";
		try {
			session = sessionFactory.openSession();
			query = session.createQuery(hql);
			entity = (RegisterEntity) query.uniqueResult();	
			transaction = session.beginTransaction();
			entity.setLoginAttempt(0);
			entity.setPassword(password);
			transaction.commit();
			
			String toMail=entity.getEmail();
			String subject="password successfully changed";
			String body="Dear"  +entity.getUserName() + ", \n"+ "Here are your Credentials" + ", \n"
					+ "Email : " +entity.getEmail() + ",\n" 
					+ "NewPassword : "+entity.getPassword() + ", \n";
			
			SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
			simpleMailMessage.setTo(toMail);
			simpleMailMessage.setSubject(subject);
			simpleMailMessage.setText(body);
			javaMailSender.send(simpleMailMessage);
			System.out.println("Mail Sent....");
			isDataChanged=true;
			
			
		}
		catch(HibernateException  hibernateException) {
			transaction.rollback();
			System.out.println("Transaction has been rolled back.. "+ hibernateException.getMessage());
			
		}
		finally {
			if(session!=null) {
				session.close();
				System.out.println("Session closed");
			}
		}
		return isDataChanged;
	}

	

//	@Override
//	public boolean updateForgotPassword(RegisterEntity registerEntity) {
//		
//		boolean isDataValid=false;
//		Transaction transaction=null;
//		session=null;
//		try {
//			
//			session = sessionFactory.openSession();
//			transaction = session.beginTransaction();
//			session.createQuery("UPDATE RegisterEntity SET loginAttempt=0 , password = :newPassword WHERE email = :email")
//                    .setParameter("newPassword", registerEntity.getPassword())
//                    .setParameter("email", registerEntity.getEmail()) 
//                    .executeUpdate();
//			transaction.commit();
//			isDataValid=true;
//		}
//		catch(Exception e) {
//			if(transaction!=null) {	
//				transaction.rollback();
//				System.out.println("transaction rollback");
//			}
//		}
//		finally {
//			
//			if(session!=null) {
//				session.close();
//				System.out.println("Session closed");
//				
//			}
//				
//		}
//		return isDataValid;
//	}

	
}
