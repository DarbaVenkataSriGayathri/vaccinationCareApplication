package com.tap.vaccine.dao;

import com.tap.vaccine.entity.AddMemberEntity;

public interface AddMemberDAO {
	
	
	
	boolean saveAddMemberDetails(AddMemberEntity addMember);

}
